var i=1;
document.write('run1 '+i);