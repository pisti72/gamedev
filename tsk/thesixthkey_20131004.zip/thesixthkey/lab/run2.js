var j=1;
document.write('run2 '+j);